﻿using Lym.BaseRespository.SdtQueuesystem;
using Lym.Model.Entity.SdtQueuesystem;
using Lym.Respository.Interface.SdtQueuesystem;
using System;
using System.Collections.Generic;
using System.Text;

namespace Lym.Respository.Service.SdtQueuesystem
{
   public class DeviceinfoRepository : BaseSdtQueuesystemRespository<Deviceinfo>, IDeviceinfoRepository
    {
    }
}
