﻿using Lym.BaseRespository;
using Lym.Model.Entity.SdtQueuesystem;
using System;
using System.Collections.Generic;
using System.Text;

namespace Lym.Respository.Interface.SdtQueuesystem
{
    public interface IDeviceinfoRepository : IBaseRespository<Deviceinfo>
    {
    }
}
